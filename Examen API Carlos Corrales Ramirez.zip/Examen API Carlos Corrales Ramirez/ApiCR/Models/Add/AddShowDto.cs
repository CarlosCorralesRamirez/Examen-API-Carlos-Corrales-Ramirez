﻿namespace ApiCR.Models.Add
{
    //Clase utilizada para la insercion de datos de la base de datos Tshows
    public class AddShowDto
    {
        //nombre a insertar en la tabla Tshows
        public string ShowName { get; set; }

        //boleano a insertar en la tabla Tshows que se refiere a si el show es favorito o no
        public bool ShowFavorite { get; set; }
    }
}
