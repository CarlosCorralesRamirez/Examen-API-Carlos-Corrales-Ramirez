﻿namespace ApiCR.Models.Update
{
    //Clase utilizada para la actualizacion de datos de la base de datos Tshows
    public class UpdateShowDto
    {
        //nombre a actualizar en la tabla Tshows
        public string ShowName { get; set; }

        //boleano a actualizar en la tabla Tshows que se refiere a si el show es favorito o no
        public bool ShowFavorite { get; set; }
    }
}
