﻿using System.ComponentModel.DataAnnotations;

namespace ApiCR.Models.Entities
{
    //Clase utilizada para la obtencion de datos de la base de datos Tshows
    public class Show
    {
        //Id a obtener de la tabla Tshows
        [Key]
        public int IdShow { get; set; }

        //nombre a obtener de la tabla Tshows
        public string ShowName { get; set; }

        //boleano a obtener de la tabla Tshows que se refiere a si el show es favorito o no
        public bool ShowFavorite { get; set; }
    }
}
