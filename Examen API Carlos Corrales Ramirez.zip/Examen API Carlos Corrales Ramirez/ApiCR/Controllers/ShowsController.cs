﻿using ApiCR.Data;
using ApiCR.Models;
using ApiCR.Models.Add;
using ApiCR.Models.Update;
using ApiCR.Models.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ApiCR.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShowsController : ControllerBase
    {
        //Se declara el contexto de la base de datos
        private readonly AplicationDbContext _context;
        public ShowsController(AplicationDbContext _context) {
            this._context = _context;
        }

        // ----------------------------------------------------------------- Metodo para obtener los shows disponibles en la tabla Tshows -----------------------------------------------------------------
        [HttpGet]
        public IActionResult GetAllShows() {
            return Ok(_context.Tshows.ToList());
        }

        // ----------------------------------------------------------------- Metodo para agregar shows en la tabla Tshows -----------------------------------------------------------------
        [HttpPost]
        public IActionResult AddShows(AddShowDto addShow) {
            var show = new Show()
            {
                ShowName = addShow.ShowName,
                ShowFavorite = addShow.ShowFavorite
            };
            _context.Tshows.Add(show);
            _context.SaveChanges();

            return Ok(show);
        }

        // ----------------------------------------------------------------- Metodo para actualizar shows en la tabla Tshows -----------------------------------------------------------------
        [HttpPut]
        //Id del show del cual se requieren actualizar los datos
        [Route("{id:int}")]
        public IActionResult UpdateShows(int id, UpdateShowDto updateShow)
        {
            //var show = new Show();
            var show = _context.Tshows.Find(id);

            if (show == null) {
                //Si el id no se encuentra se manda a llamar la excepcion para mostrar el mensaje
                throw new Exception("Invalid id to update");
            }

            show.ShowName = updateShow.ShowName;
            show.ShowFavorite = updateShow.ShowFavorite;

            _context.SaveChanges();

            return Ok(show);
        }

        // ----------------------------------------------------------------- Metodo para borrar los shows disponibles en la tabla Tshows -----------------------------------------------------------------
        [HttpDelete]
        //Id del show que se quiere borrar
        [Route("{id:int}")]
        public IActionResult DeleteShows(int id) {
            //var show = new Show();
            var show = _context.Tshows.Find(id);

            if (show == null) {
                //Si el id no se encuentra se manda a llamar la excepcion para mostrar el mensaje
                throw new Exception("Invalid id to delete");
            }

            _context.Tshows.Remove(show);
            _context.SaveChanges();

            return Ok(show);
        }

        // ----------------------------------------------------------------- Metodo para saber si el show existe en la tabla Tshows -----------------------------------------------------------------
        private bool ShowExist(int id) {
            bool exist = false;

            var show = _context.Tshows.Find(id);

            if (show == null)
            {
                exist = true;
            }

            return exist;
        }
    }
}
