﻿using ApiCR.Models.Entities;
using Microsoft.EntityFrameworkCore;
namespace ApiCR.Data
{
    public class AplicationDbContext : DbContext
    {
        public AplicationDbContext(DbContextOptions options) : base(options){

        }

        //Se establece la base de datos a utilizar, siendo esta "Tshows"
        public DbSet<Show> Tshows { get; set; }
    }
}
